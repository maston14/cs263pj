import com.yourkit.api.Controller;
import com.yourkit.api.MemorySnapshot;

import java.io.File;

public class APIDemo2 {
  public static void main(final String[] args) throws Exception {

    // Create the controller to profile the application itself.
    // (To profile another application use Controller(String host, int port).)
    final Controller controller = new Controller();

    final String snapshotFileName = controller.captureMemorySnapshot();

    System.out.println(
      "The application has captured its own memory snapshot.\n" +
      "It is saved to the file " + snapshotFileName
    );

    System.out.println();
    System.out.println("Loading captured snapshot...");

    // Load snapshot for analysis
    final MemorySnapshot snapshot = new MemorySnapshot(new File(snapshotFileName));

    // Get and print some statistics. See "Set description language" in the Help for detail.

    final String classesDescription = "<objects class=\"java.lang.Class\"/>";
    final String objectsDescription = "<objects class=\"java.lang.Object\"/>";
    final String stringsDescription = "<objects class=\"java.lang.String\"/>";

    System.out.println();
    System.out.println("Total number of classes: " + snapshot.getObjectCount(classesDescription));
    System.out.println();
    System.out.println("Total number of objects: " + snapshot.getObjectCount(objectsDescription));
    System.out.println("Size of all objects: " + snapshot.getShallowSize(objectsDescription));
    System.out.println();
    System.out.println("Number of strings: " + snapshot.getObjectCount(stringsDescription));
    System.out.println("Shallow size of all strings: " + snapshot.getShallowSize(stringsDescription));
    System.out.println(
      "Retained size of all strings: " +
      snapshot.getShallowSize("<retained-objects>" + stringsDescription + "</retained-objects>")
    );
  }
}
