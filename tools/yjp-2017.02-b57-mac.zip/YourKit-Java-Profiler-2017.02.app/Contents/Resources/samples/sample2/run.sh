#!/bin/sh

_SAMPLE_DIR_=`dirname "$0"`
YD="$_SAMPLE_DIR_/../.."

if [ "`uname | grep SunOS`" ] ; then
  JAVA_EXE="/usr/jdk/latest/bin/java"
elif [ "`uname -a | grep Linux`" ] ; then
  # Any Linux
  if [ "`uname -m | grep x86_64`" ] || [ "`uname -i | grep 86`" ] ; then
    # Intel
    if [ "`getconf LONG_BIT | grep 64`" ] ; then
      JAVA_EXE="$YD/jre64/bin/java"
    fi
  fi
fi

if [ ! -r "$JAVA_EXE" ] && [ ! -z "$JAVA_HOME" ] ; then
  JAVA_EXE="$JAVA_HOME/bin/java"
fi

if [ ! -r "$JAVA_EXE" ] ; then
  JAVA_EXE=java
fi

# Check Java version
JAVA8=`$JAVA_EXE -version 2>&1 | grep 1.8`
JAVA9=`$JAVA_EXE -version 2>&1 | grep 9-`
if [ -z "$JAVA8" ] && [ -z "$JAVA9" ] ; then
  echo "This example requires Java 8 or newer; specify appropriate Java via JAVA_HOME or PATH or edit this script ($0) explicitly"
  exit
fi

# Set AGENT_PATH to system-dependent path to the profiler agent library
AGENT_PATH=""
if [ "`uname -a | grep Linux`" ] ; then
  if [ "`uname -i | grep arm`" ] ; then
    # ARM: detect whether it is a hard- or a soft-float point
    if [ "`readelf -A $JAVA_EXE | grep 'Tag_ABI_VFP_args: VFP registers'`" ] ; then
      AGENT_PATH="$YD/bin/linux-armv7-hf/libyjpagent.so"
    else
      AGENT_PATH="$YD/bin/linux-armv5-sf/libyjpagent.so"
    fi
  elif [ "`uname -i | grep ppc64le`" ] ; then
    AGENT_PATH="$YD/bin/linux-ppc64le/libyjpagent.so"
  elif [ "`uname -i | grep ppc`" ] ; then
    if [ "`$JAVA_EXE -version 2>&1 | grep ppc64`" ] ; then
      AGENT_PATH="$YD/bin/linux-ppc-64/libyjpagent.so"
    else
      AGENT_PATH="$YD/bin/linux-ppc-32/libyjpagent.so"
    fi
  elif [ "`uname -m | grep x86_64`" ] || [ "`uname -i | grep 86`" ] ; then
    # Intel
    if [ "`$JAVA_EXE -version 2>&1 | grep 64-Bit`" ] ; then
      AGENT_PATH="$YD/bin/linux-x86-64/libyjpagent.so"
    else
      # 32-bit Java
      AGENT_PATH="$YD/bin/linux-x86-32/libyjpagent.so"
    fi
  fi
elif [ `uname` = 'Darwin' ] ; then
  AGENT_PATH="$YD/bin/mac/libyjpagent.jnilib"
elif [ `uname` = 'SunOS' ] && [ "`uname -a | grep sparc`" ] ; then
  JAVA_EXE="$JAVA_EXE -d64"
  AGENT_PATH="$YD/bin/solaris-sparc-64/libyjpagent.so"
elif [ `uname` = 'SunOS' ] && [ "`uname -a | grep i386`" ] ; then
  JAVA_EXE="$JAVA_EXE -d64"
  AGENT_PATH="$YD/bin/solaris-x86-64/libyjpagent.so"
elif [ `uname` = 'FreeBSD' ] && [ "`uname -a | grep amd64`" ] ; then
  AGENT_PATH="$YD/bin/freebsd-x86-64/libyjpagent.so"
elif [ `uname` = 'FreeBSD' ] && [ "`uname -a | grep i386`" ] ; then
  AGENT_PATH="$YD/bin/freebsd-x86-32/libyjpagent.so"
elif [ `uname` = 'HP-UX' ] ; then
  JAVA_EXE="$JAVA_EXE -d64"
  AGENT_PATH="$YD/bin/hpux-ia64-64/libyjpagent.so"
fi

if [ -z "$AGENT_PATH" ] ; then
  echo "Unsupported platform: `uname -a`"
  exit
fi

echo "Using Java: $JAVA_EXE"
echo "Using agent: $AGENT_PATH"

$JAVA_EXE "-agentpath:$AGENT_PATH" -classpath "$YD/lib/yjp.jar:$_SAMPLE_DIR_/classes" APIDemo2
