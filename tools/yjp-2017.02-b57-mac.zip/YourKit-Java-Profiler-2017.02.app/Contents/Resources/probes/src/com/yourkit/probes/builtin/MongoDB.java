/*
  Copyright (c) 2003-2017, YourKit
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions are met:

  * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

  * Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in the
    documentation and/or other materials provided with the distribution.

  * Neither the name of YourKit nor the
    names of its contributors may be used to endorse or promote products
    derived from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY YOURKIT "AS IS" AND ANY
  EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  DISCLAIMED. IN NO EVENT SHALL YOURKIT BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

package com.yourkit.probes.builtin;

import com.yourkit.probes.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;

import static com.yourkit.probes.ReflectionUtil.*;

public final class MongoDB {
  public static final String TABLE_NAME = "MongoDB";

  private static final class RequestTable extends Table {
    private final StringColumn myType = new StringColumn("Type");
    private final StringColumn myDetail = new StringColumn("Detail");

    public RequestTable() {
      super(MongoDB.class, TABLE_NAME, Table.MASK_FOR_LASTING_EVENTS);
    }
  }
  private static final RequestTable T_REQUESTS = new RequestTable();

  // insert

  @MethodPattern({
    "com.mongodb.MongoCollectionImpl : insertOne(Object)",
    "com.mongodb.MongoCollectionImpl : insertOne(Object, com.mongodb.client.model.InsertOneOptions)",
    "com.mongodb.MongoCollectionImpl : insertMany(java.util.List, com.mongodb.client.model.InsertManyOptions)"
  })
  public static final class Insert {
    public static int onEnter(@This final Object collection, @Param(1) final Object obj) {
      return enter1(collection, "insert", obj);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @ThrownException @Nullable final Throwable e) {
      exit1(rowIndex, e);
    }
  }

  // update

  @MethodPattern({
    "com.mongodb.MongoCollectionImpl : updateOne(org.bson.conversions.Bson, org.bson.conversions.Bson, com.mongodb.client.model.UpdateOptions)",
    "com.mongodb.MongoCollectionImpl : updateMany(org.bson.conversions.Bson, org.bson.conversions.Bson, com.mongodb.client.model.UpdateOptions)",
    "com.mongodb.MongoCollectionImpl : findOneAndUpdate(org.bson.conversions.Bson, org.bson.conversions.Bson, com.mongodb.client.model.FindOneAndUpdateOptions)"
  })
  public static final class Update {
    public static int onEnter(@This final Object collection, @Param(1) final Object obj) {
      return enter1(collection, "update", obj);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @ThrownException @Nullable final Throwable e) {
      exit1(rowIndex, e);
    }
  }

  // replace

  @MethodPattern({
    "com.mongodb.MongoCollectionImpl : replaceOne(org.bson.conversions.Bson, Object, com.mongodb.client.model.UpdateOptions)",
    "com.mongodb.MongoCollectionImpl : findOneAndReplace(org.bson.conversions.Bson, Object, com.mongodb.client.model.FindOneAndReplaceOptions)"
  })
  public static final class Replace {
    public static int onEnter(@This final Object collection, @Param(1) final Object obj) {
      return enter1(collection, "replace", obj);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @ThrownException @Nullable final Throwable e) {
      exit1(rowIndex, e);
    }
  }

  // delete

  @MethodPattern({
    "com.mongodb.MongoCollectionImpl : deleteOne(org.bson.conversions.Bson)",
    "com.mongodb.MongoCollectionImpl : deleteMany(org.bson.conversions.Bson)",
    "com.mongodb.MongoCollectionImpl : findOneAndDelete(org.bson.conversions.Bson, com.mongodb.client.model.FindOneAndDeleteOptions)"
  })
  public static final class Delete {
    public static int onEnter(@This final Object collection, @Param(1) final Object obj) {
      return enter1(collection, "delete", obj);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @ThrownException @Nullable final Throwable e) {
      exit1(rowIndex, e);
    }
  }

  /*
    These queries are handled in ExecuteReadOperation

    "com.mongodb.MongoCollectionImpl : count(org.bson.conversions.Bson, com.mongodb.client.model.CountOptions)"
    "com.mongodb.MongoCollectionImpl : distinct(String, org.bson.conversions.Bson, Class)",
    "com.mongodb.MongoCollectionImpl : find(org.bson.conversions.Bson, Class)",
    "com.mongodb.MongoCollectionImpl : aggregate(java.util.List, Class)",
    "com.mongodb.MongoCollectionImpl : mapReduce(String, String, Class)"
  */

  // bulk

  @MethodPattern({
    "com.mongodb.MongoCollectionImpl : bulkWrite(java.util.List, com.mongodb.client.model.BulkWriteOptions)"
  })
  public static final class Bulk {
    public static int onEnter(@This final Object collection, @Param(1) final Object obj) {
      return enter1(collection, "bulkWrite", obj);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @ThrownException @Nullable final Throwable e) {
      exit1(rowIndex, e);
    }
  }

  @MethodPattern({
    "com.mongodb.Mongo : execute(com.mongodb.operation.ReadOperation, com.mongodb.ReadPreference)"
  })
  public static final class ExecuteReadOperation {
    public static int onEnter(@Param(1) final Object operation) {
      return enter2(operation, false);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @ThrownException @Nullable final Throwable e) {
      exit2(rowIndex, e);
    }
  }

  @MethodPattern({
    "com.mongodb.Mongo : execute(com.mongodb.operation.WriteOperation)"
  })
  public static final class ExecuteWriteOperation {
    public static int onEnter(@Param(1) final Object operation) {
      return enter2(operation, true);
    }

    public static void onExit(@OnEnterResult final int rowIndex, @ThrownException @Nullable final Throwable e) {
      exit2(rowIndex, e);
    }
  }

  // common code

  private static final ThreadLocal<boolean[]> ourInsideTopCall = new ThreadLocal<boolean[]>() {
    @Override
    protected boolean[] initialValue() {
      return new boolean[1];
    }
  };

  private static int enter1(
    final Object collection,
    @NotNull final String eventType,
    @NotNull final Object descriptionObject
  ) {
    final int rowIndex = T_REQUESTS.createRow();
    if (Table.shouldIgnoreRow(rowIndex)) {
      // optimization
      return Table.NO_ROW;
    }

    T_REQUESTS.myType.setValue(rowIndex, eventType);
    T_REQUESTS.myDetail.setValue(rowIndex, "[" + ourCollection2Name.get(collection) + "] " + getDescriptionForObject(descriptionObject));

    ourInsideTopCall.get()[0] = true;

    return rowIndex;
  }

  private static void exit1(final int rowIndex, @Nullable final Throwable e) {
    ourInsideTopCall.get()[0] = false;
    T_REQUESTS.closeRow(rowIndex, e);
  }

  static final class OperationTypeMap extends HashMap<String, String> {
    /**
     * sic: parameter order is (value, key) for readability!
     */
    OperationTypeMap append(@NotNull final String type, @NotNull final String className) {
      put(className, type);
      return this;
    }
  }

  static final OperationTypeMap ourReadOperation2Type = new OperationTypeMap()
    .append("aggregate", "com.mongodb.operation.AggregateOperation")
    .append("aggregate", "com.mongodb.operation.AggregateExplainOperation")

    .append("count", "com.mongodb.operation.CountOperation")
    .append("find", "com.mongodb.operation.FindOperation")

    .append("list", "com.mongodb.operation.ListDatabasesOperation")
    .append("list", "com.mongodb.operation.ListIndexesOperation")
    .append("list", "com.mongodb.operation.ListCollectionsOperation")

    .append("mapReduce", "com.mongodb.operation.MapReduceWithInlineResultsOperation")

    .append("distinct", "com.mongodb.operation.DistinctOperation");

  static final OperationTypeMap ourWriteOperation2Type = new OperationTypeMap()
    .append("createIndex", "com.mongodb.operation.CreateIndexesOperation")

    .append("createCollection", "com.mongodb.operation.CreateCollectionOperation")

    .append("update", "com.mongodb.operation.UpdateOperation")
    .append("update", "com.mongodb.operation.FindAndUpdateOperation")

    .append("replace", "com.mongodb.operation.FindAndReplaceOperation")

    .append("insert", "com.mongodb.operation.InsertOperation")

    .append("aggregate (write)", "com.mongodb.operation.AggregateToCollectionOperation") // write operation

    .append("mapReduce (write)", "com.mongodb.operation.MapReduceToCollectionOperation")  // write operation

    .append("delete", "com.mongodb.operation.DeleteOperation")
    .append("delete", "com.mongodb.operation.FindAndDeleteOperation")

    .append("drop", "com.mongodb.operation.DropCollectionOperation")
    .append("drop", "com.mongodb.operation.DropDatabaseOperation")
    .append("drop", "com.mongodb.operation.DropIndexOperation")
    .append("drop", "com.mongodb.operation.DropUserOperation");

  static final OperationTypeMap ourWriteRequestToType = new OperationTypeMap()
    .append("insert", "com.mongodb.InsertRequest")
    .append("insert", "com.mongodb.bulk.InsertRequest")

    .append("update", "com.mongodb.UpdateRequest")
    .append("update", "com.mongodb.bulk.UpdateRequest")

    .append("delete", "com.mongodb.DeleteRequest")
    .append("delete", "com.mongodb.bulk.DeleteRequest")

    .append("replace", "com.mongodb.ReplaceRequest")
    .append("replace", "com.mongodb.bulk.ReplaceRequest");

  private static int enter2(
    @Nullable final Object operation,
    final boolean isWrite
  ) {
    if (operation == null) {
      // impossible?
      return Table.NO_ROW;
    }
    if (ourInsideTopCall.get()[0]) {
      // top level event has been added - don't process execute
      return Table.NO_ROW;
    }

    final int rowIndex = T_REQUESTS.createRow();
    if (Table.shouldIgnoreRow(rowIndex)) {
      // optimization
      return Table.NO_ROW;
    }

    final String operationClassName = operation.getClass().getName();

    final String eventType;
    String description = null;
    if (isWrite) {
      // WriteOperation

      if (operationClassName.endsWith("MixedBulkWriteOperation")) {
        final List requests = (List)callMethod0(operation, "getWriteRequests:()Ljava/util/List;");
        if (requests != null) {
          final int size = requests.size();
          if (size == 1) {
            final Object request = requests.get(0);
            final String requestClassName = request.getClass().getName();

            final String type = ourWriteRequestToType.get(requestClassName);
            eventType = type != null ? type : getDescriptionForObject(request);
          }
          else {
            eventType = "bulkWrite";
            description = "count=" + size;
          }
        }
        else {
          // is this possible?
          eventType = "(other write)";
        }
      }
      else {
        final String type = ourWriteOperation2Type.get(operationClassName);
        eventType = type != null ? type : "(other write)";
      }
    }
    else {
      // ReadOperation

      final String type = ourReadOperation2Type.get(operationClassName);
      eventType = type != null ? type : "(other read)";
    }

    if (description == null) {
      description = getDocDescriptionViaGetFilter(operation);
    }

    final String namespace = getNamespaceFromOperation(operation);

    T_REQUESTS.myType.setValue(rowIndex, eventType);
    T_REQUESTS.myDetail.setValue(rowIndex, (namespace != null ? "[" + namespace + "] " : "") + description);
    return rowIndex;
  }

  private static void exit2(final int rowIndex, @Nullable final Throwable e) {
    T_REQUESTS.closeRow(rowIndex, e);
  }

  @NotNull
  private static String getDocDescriptionViaGetFilter(@NotNull final Object operation) {
    final Object doc = callMethod0(operation, "getFilter:()Lorg/bson/BsonDocument;");
    return doc != null ? getDescriptionForObject(doc) : "{}";
  }

  @NotNull
  private static String getDescriptionForObject(@NotNull final Object descriptionObject) {
    if (descriptionObject instanceof String) {
      return (String)descriptionObject;
    }

    if (descriptionObject instanceof Map) {
      final Set<?> keySet = ((Map)descriptionObject).keySet();
      if (keySet.isEmpty()) {
        // optimization
        return "{}";
      }

      final StringBuilder result = new StringBuilder();
      result.append('{');

      for (final Object key : keySet) {
        if (!(key instanceof String)) {
          continue;
        }

        if (result.length() > 1) {
          result.append(", ");
        }
        result.append(key);
      }

      result.append('}');

      return result.toString();
    }

    if (descriptionObject instanceof List) {
      return "count=" + ((List)descriptionObject).size();
    }

    final String descriptionObjectClassName = descriptionObject.getClass().getName();
    if (descriptionObjectClassName.endsWith("SimpleEncodingFilter")) {
      final String fieldName = getFieldValue(descriptionObject, "fieldName:" + STRING_SIG);
      if (fieldName != null) {
        return "{" + fieldName + "}";
      }
    }

    return descriptionObjectClassName;
  }

  @Nullable
  static String getNamespaceFromOperation(@NotNull final Object operation) {
    final Object namespace = getFieldValue(operation, "namespace:Lcom/mongodb/MongoNamespace;");
    if (namespace != null) {
      final String name = callMethod0String(namespace, "getFullName");
      if (name != null) {
        return name;
      }
    }

    final String databaseName = getFieldValue(operation, "databaseName:" + STRING_SIG);
    final String collectionName = getFieldValue(operation, "collectionName:" + STRING_SIG);

    if (databaseName == null && collectionName == null) {
      return null;
    }

    if (databaseName != null && collectionName != null) {
      return databaseName + "." + collectionName;
    }

    return collectionName == null ? databaseName : collectionName;
  }

  @NotNull
  static String getNamespaceFromCollection(@NotNull final Object collection) {
    // MongoCollection collection;
    // collection.getNamespace().getFullName();

    final Object namespace = callMethod0(collection, "getNamespace:()Lcom/mongodb/MongoNamespace;");
    if (namespace == null) {
      return "<unknown>";
    }

    final String name = callMethod0String(namespace, "getFullName");
    if (name == null) {
      return "<unknown>";
    }

    return name;
  }

  private static final LazyMap<Object, String> ourCollection2Name = new LazyMap<Object, String>() {
    @NotNull
    @Override
    protected String calculateValue(@NotNull final Object collection) {
      return getNamespaceFromCollection(collection);
    }
  };
}
